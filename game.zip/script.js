var spieler = document.querySelector(".player");
spieler.style.left = "0px";

var score = 0;
var punkteAnzeige = document.querySelector(".punkte");

var timer = new Timer(30);

var spielfeld = document.querySelector(".playground");
var backgroundPosition = 0;

var vollbildButton = document.querySelector(".fullscreen");

vollbildButton.addEventListener("click", function () {
  spielfeld.requestFullscreen();
});

function loop() {
  backgroundPosition = backgroundPosition + 5;
  spielfeld.style.backgroundPosition = `-${backgroundPosition}px 0`;

  if (parseInt(spieler.style.top) < 200) {
    spieler.style.top = parseInt(spieler.style.top) + 5 + "px";
  }

  if (timer.ready()) {
    var h = document.createElement("div");
    h.classList.add("stein");
    h.style.top = "0px";
    h.style.right = "0px";
    spielfeld.appendChild(h);
  }

  var steine = document.querySelectorAll(".stein");
  for (var stein of steine) {
    stein.style.right = parseInt(stein.style.right) + 5 + "px";
    if (parseInt(stein.style.right) > 1180) {
      stein.parentNode.removeChild(stein);
    }
  }

  if (parseInt(spieler.style.left) > 200) {
    score = score + 1;
    punkteAnzeige.textContent = score;
  }

  if (keyboard(32)) {
    spieler.style.bottom = parseInt(spieler.style.bottom) + 5 + "px";
  }

  window.requestAnimationFrame(loop);
}

window.requestAnimationFrame(loop);
